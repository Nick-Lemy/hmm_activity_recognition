# Modeling Human Activity States Using Hidden Markov Models

**Group members:** _names_ · **GitHub repo:** _link_ · **Date:** _…_

---

## 1. Background and Motivation

_One paragraph. State your group's **unique use case** — pick one and make it concrete, e.g.:
fall-risk monitoring for elderly relatives, step-vs-rest tracking for a low-cost fitness app,
motion-triggered smart-home lighting, or physiotherapy adherence monitoring. Connect it to why
human activity recognition (HAR) matters: raw accelerometer/gyroscope streams are noisy and the
true activity is hidden, which is exactly the structure an HMM models._

## 2. Data Collection and Preprocessing

- **App & sensors:** Sensor Logger; accelerometer (x, y, z) and gyroscope (x, y, z).
- **Protocol:** 5–10 s recordings per file for four activities (still, standing, walking,
  jumping); ~50 files total; ≥ 1 min 30 s cumulative per activity. Unseen test data collected in
  a **separate session** (_state: different day / participant / environment_).
- **Sampling rates per member** (from the notebook's summary table):

  | Member | Phone | Native rate (Hz) |
  |---|---|---|
  | _…_ | _…_ | _…_ |

- **Harmonization:** all recordings linearly interpolated onto a uniform **50 Hz** grid so
  windows and FFT bins are comparable across phones. _Explain in one or two sentences why your
  target rate is a sensible common denominator for your phones._
- **Windowing:** 1-second windows (50 samples at 50 Hz) with 50% overlap. Justification: a window
  must contain at least one full cycle of the slowest periodic activity (walking ≈ 1.5–2.5 Hz →
  period ≤ 0.7 s), while staying short enough to be quasi-stationary; overlap increases the number
  of observations.
- _Insert Figure 1: raw accelerometer traces, one per activity (from the notebook)._

## 3. HMM Setup and Implementation

- **Hidden states (Z):** the four activities. **Observations (X):** 7-D feature vector per window.
- **Features and why they discriminate** (_personalize using your box plots_):
  time-domain — mean of acc-z (orientation/gravity), std and RMS of acceleration magnitude
  (motion intensity), signal magnitude area (SMA), x–z axis correlation (gait coupling);
  frequency-domain (FFT of gravity-removed magnitude) — dominant frequency (walking vs jumping
  cadence), spectral energy in the 0.5–10 Hz band (dynamic vs static).
- **Normalization:** z-score using training-set statistics only, so all features share a scale
  suitable for Gaussian emissions and no test information leaks into training.
- **Model:** Gaussian emissions with diagonal covariance; π, A, μ, σ² learned with **Baum–Welch**;
  all computations in log-space. Convergence criterion: **|ΔLL| < 10⁻⁴** (converged in _n_
  iterations — cite the LL curve). **Viterbi** decodes the most likely activity sequence.
- _Insert Figure 2: log-likelihood convergence curve._

## 4. Results and Interpretation

- _Insert Figure 3: transition-matrix heatmap + emission-means heatmap._ Comment on the strong
  diagonal (activities persist across 1-s windows) and any meaningful off-diagonal transitions.
- _Insert Figure 4: confusion matrix on unseen data; Figure 5: decoded sequence plot(s)._
- Evaluation on **unseen data** (how obtained: _…_):

  | State (Activity) | Number of Samples | Sensitivity | Specificity | Overall Accuracy |
  |---|---|---|---|---|
  | Still | | | | |
  | Standing | | | | |
  | Walking | | | | |
  | Jumping | | | | |

  _Copy the numbers from the notebook's metrics table, then interpret them — don't just list them.
  Which classes generalize? Where does the model fail on the new session, and why?_

## 5. Discussion and Conclusion

Address explicitly, in your own words, grounded in **your** figures:

1. **Easiest / hardest activities to distinguish** and the evidence (confusion matrix, feature
   distributions).
2. **Are the learned transition probabilities behaviorally realistic?**
3. **Impact of sensor noise and sampling-rate differences** between members' phones; what
   interpolation to 50 Hz might smooth away.
4. **Improvements:** more data and participants, orientation-invariant features, extra sensors
   (magnetometer, barometer), longer windows for finer frequency resolution, semi-supervised
   emission initialization, etc.

One-paragraph conclusion tying results back to the Section 1 use case.

---
_Format: 4–5 pages, captioned figures, exported as PDF._
